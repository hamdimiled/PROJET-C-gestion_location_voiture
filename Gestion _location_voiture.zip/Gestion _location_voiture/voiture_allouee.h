#pragma once
#include "voiture.h"
#include "date.h"
#include "client.h"
class  voiture_allouee : public voiture
{    
	  date date_debut;
      date date_fin;
	  client c;
	  float prix_a_payer;
	  int duree;
public:
	voiture_allouee(void);
	~voiture_allouee(void);
	int calcul_duree ();
	float calcul_prix() ;
	//date getdate_debut(){return date_debut;}
	//date getdate_fin(){return date_fin;}
};

