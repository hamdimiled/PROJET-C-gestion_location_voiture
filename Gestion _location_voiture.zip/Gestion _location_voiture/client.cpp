#include "client.h"

client::client()
{
}
void client::saisir_client()
{
	cout<<" prenom de client  : "<<endl;
	cin>>prenom;
	cout<<" nom de client  "<<endl;
	cin>>nom;
	cout<<" nm cin  : "<<endl;
	cin>>cinationale;
	cout<<" nm telephone : "<<endl ;
	cin>>telephone;
	cout<<" age client "<<endl ;
	cin>>age ;
	cout<<" date emprunt"<<endl ;
	cin>>date_emprunt ;
	cout<<" date_retour : "<<endl ;
	cin>>date_retour;
}



client::~client(void)
{
}
