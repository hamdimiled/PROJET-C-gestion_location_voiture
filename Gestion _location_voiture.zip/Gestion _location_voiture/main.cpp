#include"voiture.h" 
#include"voiture_allouee.h"
#include"client.h"
#include"stock.h" 
#include<iostream>
#include <fstream>
#include"menu.h"
 using namespace std; 
void main() 
{
	fstream f,f1;
int choix1,choix2;
int h;
stock  c;
voiture v ;
voiture_allouee vl ;
client cl ;
etiquete: choix1=menu_principal();


 switch (choix1)

	{
	case 1 :
		{
		etiquette: choix2=menu_gestion_voiture();
		switch(choix2)
		{
		
		case 1 :
			{
				 v.saisir();
                 c.ajoutV(v,c.taille());
                 c.ouvrir(f);
                 c.enregistrer(f,c);
			     cout<<"\n appuyer sur \xba 1 \xba pour retour au menu principal \n\n appuyer sur \xba 2 \xba pour retour au menu gestion_voiture   :  "<<endl;
		   	     cin>>h ;
			     if (h==1)
				  goto etiquete ;
			    else
				goto etiquette ;
           }; break;
		 case 2 : 
			{
				c.afficherStock(); // affichage depuis vector
				//c.afficher(f );
				cout<<"\n appuyer sur \xba 1 \xba pour retour au menu principal \n\n appuyer sur \xba 2 \xba pour retour au menu gestion_voiture   :  "<<endl;
			    cin>>h;
			    if (h==1)
				 goto etiquete ;
			   else
				goto etiquette ;

			}; break;
		 case 3 :
			 {
				 c.afficher(f1);
				 cout<<"\n appuyer sur \xba 1 \xba pour retour au menu principal \n\n appuyer sur \xba 2 \xba pour retour au menu gestion_voiture   :  "<<endl;
			    cin>>h;
			    if (h==1)
				 goto etiquete ;
			   else
				goto etiquette ;
			 }; break;
		 case 4 :
			 {
				 cout<<"donner matricule de voiture souhaite supprimer "<<endl ; //prb
				 int n ;
				 cin>>n ;
				 c.supprimer_voiture(n) ;
				   cout<<"\n appuyer sur \xba 1 \xba pour retour au menu principal \n\n appuyer sur \xba 2 \xba pour retour au menu gestion_voiture   :  "<<endl;
		   	     cin>>h ;
			     if (h==1)
				  goto etiquete ;
			    else
				goto etiquette ;
			 }; break ;

				 
		case 5 : goto etiquete ;  

		case 6: exit(-1) ;break ;
		 
		}
	case 2 :
		{
			cout<<" \n           taper 1 pour afficher tableau de voiture et choisir une voiture \n          "<<endl;
		   do
		   cin>>h ;
		   while(h!=1);
			c.afficherStock();
			cout<<"  donner matricule de voiture souhaite emprunter    "<<endl ;
			cin>>h ;
			
			voiture *s=c.chercher_voiture(h);
			c.ouvrir_vl(f1);
            c.enregistrer_vl(f1,*s);
			c.supprimer_voiture(h);
			cl.saisir_client() ;

			int a ;

			a=vl.calcul_duree();
			cout<<" facture "<<a<<" $ "<<endl  ;
			 cout<<"\n appuyer sur \xba 1 \xba pour retour au menu principal \n\n appuyer sur \xba 2 \xba pour retour au menu gestion_voiture   :  "<<endl;
		   	     cin>>h ;
			     if (h==1)
				  goto etiquete ;
			    else
				goto etiquette ;
		};  break ;
	case 3 : exit(-2);break;
		} 
 }



	system("PAUSE") ;

}