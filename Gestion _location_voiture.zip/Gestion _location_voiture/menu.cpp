#include<iostream>
using namespace std ;
#include"menu.h"
int menu_principal()
{
int choix;
        cout<<"         -------------------------------------------------------"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |               Gestion Location Voiture                |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |    1. Gestion voiture                                 |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |    2. Gestion client                                  |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |    3. Quitter                                         |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"         -------------------------------------------------------"<<endl;
	
	do
	{
	cout<<"\n\n                                     donnez Votre choix  :  "<<endl;
	cin>>choix ;
	}
	while (choix <1||choix >3);
	return choix ;
}
int menu_gestion_voiture()
{
	int choixx;
	    cout<<"         -------------------------------------------------------"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |               Gestion Voiture                         |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |     1. Ajouter voiture.                               |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |     2. afficher stock voiture                         |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |     3.afficher voiture allouer                        |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |     4.supprimer voiture                               |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |     5.Retour                                          |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |     6. Quitter                                        |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"         -------------------------------------------------------"<<endl;
	
	do
	{
      cout<<"\n donner le choix \n"<<endl ;
	  cin>>choixx ;
   	}
    while (choixx <1||choixx >6);
	return choixx;
}