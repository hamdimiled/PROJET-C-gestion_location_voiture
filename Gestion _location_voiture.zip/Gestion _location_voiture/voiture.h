#pragma once
#include<string>
#include<iostream>
using namespace std ;
#include<fstream>
class voiture // classe mere de  voiture alloue ;
{   
	friend class stock; // les methodes de la classe stock peuvent acceder aux attributs de la classe voiture 
protected : 
    int matricule ;
	int serie;
	string modele;
	string nomv;
	string couleur ;
	float prix ;
public:
	voiture(void);
	virtual ~voiture(void);
	void saisir () ;
	void enregistrer_fichier () ;
	void afficher_voiture() ;
	friend ostream& operator<<(ostream&,voiture&);
	friend istream& operator>>(istream&,voiture&);
	voiture& operator= (const voiture&);
	int getMatricule(){return matricule;}

};

