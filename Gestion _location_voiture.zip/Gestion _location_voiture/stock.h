#pragma once
#include<vector>
#include<string>
#include"voiture_allouee.h"
class stock : public voiture 
{
protected :
	vector<voiture*> tabV;
	

public:
	stock(void);
	stock(const stock&); //constructeur de recopie d'une partie dynamique utulise typeid pour identifier le type & staticcast pour la conversion des types
	friend ostream& operator<<(ostream&, stock&);
	friend istream& operator>>(istream&, stock&);
	voiture* chercher_voiture(int); 
	void ajoutV(voiture, int);
	void supprimer_voiture(int);
	stock& operator= (const stock&); //Sucharge de l'op�rateur d'affectation (operator=)
	static void ouvrir(fstream&); 
	static void ouvrir_vl(fstream&); //ouvrir fichier  de voiture allouee
	static void enregistrer(fstream &, stock&);
	static void enregistrer_vl(fstream &, voiture&);
    static void afficher(fstream&);
	void afficherStock() ;
	int taille(){return tabV.size();};
	~stock(void);
};

