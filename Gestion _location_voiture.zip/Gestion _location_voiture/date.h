#pragma once
#include<iostream>
using namespace std;

class date
{	
public:
	int jour;
	int mois;
	int annee;
public:
	date(void);
	date(int,int,int);
	friend ostream& operator<< (ostream&, date&);
	friend istream& operator>> (istream&,date&);
	friend int operator-(date,date); // ou int operator-(const date&); // sera utulise pour calculer la duree entre deux dates ;
	~date(void);
};