#include "stock.h"
#include<iomanip>


stock::stock(void)
{
}

stock::stock(const stock& p)
{
	voiture* q;
    for (int i=0;i<p.tabV.size();i++)
            {   if (typeid (*p.tabV[i]) == typeid (voiture))
				q=new voiture (*p.tabV[i]);
			   else if  (typeid (*p.tabV[i]) == typeid (voiture_allouee)) 
				 q=new voiture_allouee ( static_cast <const voiture_allouee&> (*p.tabV[i])) ;
				tabV.push_back(q);
			}
	
}
ostream& operator<< (ostream& out, stock &r) 
{ 
for(int i=0; i<r.tabV.size(); i++) 
out<<*r.tabV[i]<<setw(7)<<endl;
return out; 
} 

voiture* stock::chercher_voiture(int n) 
{ 
for(int i=0; i<tabV.size(); i++) 
if (tabV[i]->matricule == n) return tabV[i]; //la classe stock est ami avec la classe voiture elle n'a pas besoin d'avoir des getteurs
return NULL;
}

void stock::ajoutV(voiture v,int ind)
{   
	voiture *q=new voiture(v);
	tabV.insert(tabV.begin()+ind, q);
}
void stock::supprimer_voiture(int m)
{
	for(int i=0; i<tabV.size(); i++)
		{if(tabV[i]->matricule==m) //la classe stock est ami avec la classe voiture elle n'a pas besoin d'avoir des getteurs
			tabV.erase(tabV.begin()+i);
		else
			cout<<"erreur"<<endl;
		}
}





stock& stock::operator= (const stock & w) 
{ 
if(this!=&w) 
{
for(int i=0; i<tabV.size(); i++) 
delete tabV[i]; 
tabV.clear(); 

for(int i=0; i<w.tabV.size(); i++) 

{ 
voiture *c=new voiture(*w.tabV[i]); 
tabV.push_back(c); 
} 

} 
return *this; 
}

void stock::ouvrir(fstream &f) 
{ 
f.open("stock.txt", ios::in | ios::out | ios::app); 
if( !f.is_open()) exit(-1); 
} 
void stock::ouvrir_vl(fstream &f) 
{ 
f.open("stock_vl.txt", ios::in | ios::out | ios::app); 
if( !f.is_open()) exit(-1); 
} 
void stock::enregistrer(fstream& f, stock& p)
{
f<<p;
}
void stock::enregistrer_vl(fstream& f, voiture & p)
{
f<<p;
}




void stock::afficher(fstream &es) 
{ 
cout<<"\n affichage du fichier "<<endl; 
es.seekg(0); 
char ch[500]; 
while(1) 
{ 
es.getline(ch,500); 
if( es.eof()) break; 
cout<<ch<<endl; 
} 
} 

void stock::afficherStock()
{
	if(tabV.size()==0) cout<<"stock vide!!!"<<endl;
	for(int i=0;i<tabV.size();i++)
	{
		cout<<"\nvoiture n"<<i+1<<endl;
		tabV[i]->afficher_voiture();
	}
}
stock::~stock(void)
{
}  

