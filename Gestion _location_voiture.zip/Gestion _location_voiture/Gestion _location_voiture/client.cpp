#include "client.h"


client::client(void)
{
}


client::~client(void)
{
}
