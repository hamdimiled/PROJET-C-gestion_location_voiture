#include "stock.h"
#include<iomanip>

stock::stock(void)
{
}

stock::stock(const stock& p)
{
	voiture* q;
    for (int i=0;i<p.tabV.size();i++)
            {
				q=new voiture (*p.tabV[i]);
				tabV.push_back(q);
			}
	
}
ostream& operator<< (ostream& out, stock &r) 
{ 
for(int i=0; i<r.tabV.size(); i++) 
out<<*r.tabV[i]<<setw(7)<<endl;
return out; 
} 

voiture* stock::chercher_voiture(int n) 
{ 
for(int i=0; i<tabV.size(); i++) 
if ((tabV[i]->getMatricule())==n) return tabV[i]; 
return NULL;
}

void stock::ajoutV(voiture v,int ind)
{
	voiture *q=new voiture(v);
	tabV.insert(tabV.begin()+ind, q);
}
void stock::supprimer_voiture(int m)
{
	for(int i=0; i<tabV.size(); i++)
		{if(tabV[i]->getMatricule()==m)
			tabV.erase(tabV.begin()+i);
		else
			cout<<"erreur"<<endl;
		}
}
stock& stock::operator= (const stock & w) 
{ 
if(this!=&w) 
{
for(int i=0; i<tabV.size(); i++) 
delete tabV[i]; 
tabV.clear(); 

for(int i=0; i<w.tabV.size(); i++) 

{ 
voiture *c=new voiture(*w.tabV[i]); 
tabV.push_back(c); 
} 

} 
return *this; 
}

void stock::ouvrir(fstream &f) 
{ 
f.open("stock.txt", ios::in | ios::out | ios::app); 
if( !f.is_open()) exit(-1); 
} 

void stock::enregistrer(fstream& f, stock& p)
{
f<<p;
}

void stock::sauvegarder(fstream &f) 
{ 
f<<(*this); 
}

void stock::afficher(fstream &es) 
{ 
cout<<"\n affichage du fichier "<<endl; 
es.seekg(0); 
char ch[500]; 
while(1) 
{ 
es.getline(ch,500); 
if( es.eof()) break; 
cout<<ch<<endl; 
} 
} 

void stock::copiervoituredansFichier(fstream& f)
 {for (int i=0;i<tabV.size();i++)
 
	 f<<(*tabV[i])<<endl;
 }
stock::~stock(void)
{
}

