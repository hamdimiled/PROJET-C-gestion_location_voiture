#pragma once
#include<string>
using namespace std ;
#include "date.h"
class client
{
	string prenom;
	string nom;
	int cin ;
	int prix ;
	long telephone	 ;
	int age ;
	date date_emprunt;
	date date_retour;
public:
	client(void);
	~client(void);
	void saisir_client();
	void enregistrer_fichier_client(); 
};

