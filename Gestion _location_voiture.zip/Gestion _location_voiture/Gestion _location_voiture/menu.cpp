#include<iostream>
using namespace std ;
#include"menu.h"
int menu_principal()
{
int choix;
        cout<<"         -------------------------------------------------------"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |               Gestion Location Voiture                |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |    1. Gestion voiture                                 |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |    2. Gestion client                                  |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |    3. Quitter                                         |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"         -------------------------------------------------------"<<endl;
	
	do
	{
	cout<<"\n\n                                     donnez Votre choix  :  "<<endl;
	cin>>choix ;
	}
	while (choix <1||choix >3);
	return choix ;
}
int menu_gestion_voiture()
{
	int choixx;
	    cout<<"         -------------------------------------------------------"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |               Gestion Voiture                         |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |     1. Ajouter voiture.                               |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |     2. afficher voiture                               |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |     3.supprimer voiture                               |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |     4.Retour                                          |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |     5. Quitter                                        |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"        |                                                       |"<<endl;
		cout<<"         -------------------------------------------------------"<<endl;
	
	do
	{
      cout<<"\n donner le choix \n"<<endl ;
	  cin>>choixx ;
   	}
    while (choixx <1||choixx >5);
	return choixx;
}