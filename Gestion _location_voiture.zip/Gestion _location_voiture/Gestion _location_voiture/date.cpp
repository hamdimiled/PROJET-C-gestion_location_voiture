#include "date.h"
#include<iostream>
#include<fstream>
using namespace std;
#include<iomanip>

date::date(void)
{
}


istream& operator >> (istream& in ,date& D)
{
	
	
	
	

	cout<<"\n	 Saisir l'annee	:	";
			in>>D.annee;

	cout<<"\n	 Saisir le mois	:	";
			in>>D.mois;

	cout<<"\n	 Saisir le jour	:	";
			in>>D.jour;

	return in;


}


ostream& operator << (ostream& out,date& D)
{
	out<<D.jour<<"/"<<D.mois<<"/"<<D.annee;
	return out;
}
	
date::~date(void)
{
}