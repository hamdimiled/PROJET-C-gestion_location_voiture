#pragma once
#include<vector>
#include<string>
#include "voiture.h"
class stock : public voiture 
{
protected :
	vector<voiture*> tabV;

public:
	stock(void);
	stock(const stock&);
	friend ostream& operator<<(ostream&, stock&);
	friend istream& operator>>(istream&, stock&);
	voiture* chercher_voiture(int); 
	void ajoutV(voiture, int);
	void supprimer_voiture(int );
	stock& operator= (const stock&); //Sucharge de l'op�rateur d'affectation (operator=)
	static void ouvrir(fstream&); 
	void sauvegarder(fstream&); 
	static  void enregistrer(fstream &, stock&);
	static void afficher(fstream&);
	void copiervoituredansFichier(fstream&);
	int taille(){return tabV.size();};
	~stock(void);
};

