#pragma once
#include<string>
#include<iostream>
using namespace std ;
#include<fstream>
class voiture
{
protected :
    int matricule ;
	int serie;
	string modele;
	string nomv;
	string couleur ;
	int prix ;
public:
	voiture(void);
	~voiture(void);
	void saisir () ;
	void enregistrer_fichier () ;
	friend ostream& operator<<(ostream&,voiture&);
	friend istream& operator>>(istream&,voiture&);
	voiture& operator= (const voiture&);
	int getMatricule(){return matricule;}

};

