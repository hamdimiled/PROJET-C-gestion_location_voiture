#include"voiture.h" 
#include"client.h"
#include"stock.h" 
#include<iostream>
#include <fstream>
#include"menu.h"
 using namespace std; 
void main() 
{
	fstream f;
int choix1,choix2;
int h;
stock  c;
voiture v ;
client cl ;
etiquete: choix1=menu_principal();


 switch (choix1)

	{
	case 1 :
		{
		etiquette: choix2=menu_gestion_voiture();
		switch(choix2)
		{
		
		case 1 :
			{
				 v.saisir();
                 c.ajoutV(v,c.taille());
                 c.ouvrir(f);
                 c.enregistrer(f,c);
			     cout<<"\n appuyer sur \xba 1 \xba pour retour au menu principal \n\n appuyer sur \xba 2 \xba pour retour au menu gestion_voiture   :  "<<endl;
		   	     cin>>h ;
			     if (h==1)
				  goto etiquete ;
			    else
				goto etiquette ;
           }; break;
		 case 2 : 
			{
				c.afficher(f );
				cout<<"\n appuyer sur \xba 1 \xba pour retour au menu principal \n\n appuyer sur \xba 2 \xba pour retour au menu gestion_voiture   :  "<<endl;
			    cin>>h;
			    if (h==1)
				 goto etiquete ;
			   else
				goto etiquette ;

			}; break;
		 case 3 :
			 {
				 cout<<"donner matricule de voiture souhaite supprimer "<<endl ;
				 int n ;
				 cin>>n ;
				 c.supprimer_voiture(n) ;
				   cout<<"\n appuyer sur \xba 1 \xba pour retour au menu principal \n\n appuyer sur \xba 2 \xba pour retour au menu gestion_voiture   :  "<<endl;
		   	     cin>>h ;
			     if (h==1)
				  goto etiquete ;
			    else
				goto etiquette ;
			 }; break ;

				 
		case 4 : goto etiquete ;  

		case 5: exit(-1) ;break ;
		 
		}
	case 2 : exit(-2) ; break ;
		} 
 }



	system("PAUSE") ;

}