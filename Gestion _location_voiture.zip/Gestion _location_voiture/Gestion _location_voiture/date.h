#pragma once
#include<iostream>
using namespace std;

class date
{	
public:
	int jour;
	int mois;
	int annee;
public:
	date(void);
	date(int,int,int);
	friend ostream& operator<< (ostream&, date&);
	friend istream& operator>> (istream&,date&);
	~date(void);
};