#include "voiture.h"


voiture::voiture()
{
	matricule=0;
	serie=0;
	modele="";
	nomv="";
	couleur="";
	prix=0 ;


}

void voiture::saisir()
{
	cout<<"Saisir le matricule de la voiture : "<<endl;
	cin>>matricule;
	cout<<"Saisir nm serie "<<endl;
	cin>>serie;
	cout<<"Saisir nom de voiture  : "<<endl;
	cin>>nomv;
	cout<<"Saisir  modele de voiture "<<endl ;
	cin>>modele ;
	cout<<"Saisir couleur de voiture "<<endl ;
	cin>>couleur ;
	cout<<"Saisir prix "<<endl ;
	cin>>prix ;
}
ostream& operator<<(ostream& out,voiture& v)
{
	out<<"Matricule : "<<v.matricule<<"  "<<"nm serie : "<<v.serie<<"  "<<" modele : "<<v.modele<<" "<<"nom : "<<v.nomv<<"    "<<" couleur : "<<v.couleur<<"   "<<"prix : "<<v.prix<<endl;

return out;
}

istream& operator>>(istream& in,voiture& v)
{
	cout<<"\n Saisir le matricule de la voiture "<<endl;
	in>>v.matricule;
	cout<<"\n Saisir nm serie "<<endl;
	in>>v.serie;
	cout<<"\n Saisir modele de voiture  "<<endl;
	in>>v.modele;
	cout<<"\n saisir nom de voiture "<<endl ;
	in>>v.nomv ;
	cout<<" \n saisir couleur de voiture "<<endl ;
	in>>v.couleur ;
	cout<<" \n saiir prix "<<endl ;
	in>>v.prix ;

return in;
}

voiture& voiture::operator= (const voiture & w)
{
if(this!=&w)
{
matricule=w.matricule;
serie=w.serie;
modele=w.modele;
nomv=w.nomv ;
couleur=w.couleur;
prix=w.prix ;
}
return *this;
}
voiture::~voiture(void)
{
}
