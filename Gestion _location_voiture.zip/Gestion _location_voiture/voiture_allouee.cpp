#include "voiture_allouee.h"


voiture_allouee::voiture_allouee(void) : voiture () // voiture allouee herite de voiture son constructeur doit appelee celui de la classe de base
{
}

int voiture_allouee::calcul_duree()
{
	int a ;
	a=(date_fin - date_debut);
	return a ;
}
float voiture_allouee::calcul_prix()
{
float p=0;
p =calcul_duree() * prix ;
return (p);
	
}

voiture_allouee::~voiture_allouee(void)
{
}
